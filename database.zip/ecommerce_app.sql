-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2023 at 06:46 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `user_name` varchar(16) NOT NULL,
  `product_id` varchar(5) NOT NULL,
  `quantity` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`user_name`, `product_id`, `quantity`) VALUES
('Krish_Serchan003', 'CD483', 2),
('Nayan_Pandey2002', 'HM281', 3),
('Nayan_Pandey2002', 'ZA567', 1),
('Rahul_Balami2004', 'HM281', 3),
('Ureeka_Serchan03', 'CD198', 1),
('Ureeka_Serchan03', 'CD483', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` varchar(5) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `rating` int(1) NOT NULL,
  `unit_price` int(5) NOT NULL,
  `stock` int(3) NOT NULL,
  `photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `category`, `brand`, `rating`, `unit_price`, `stock`, `photo`) VALUES
('CD198', 'Sheer Long Sleeve Top & Tank Top', 'Women Shirts', 'Cider', 5, 2000, 9, '1681475407000-MSrMc2.jpg'),
('CD483', ' Off-shoulder Ruched Crop Top', 'Women Shirts', 'Cider', 4, 1200, 12, '1679905596000-iMeZhd.jpg'),
('HM281', 'RED STRIPED POCKET TSHIRT', 'Kids', 'H&M', 2, 1250, 14, 'BRANDED-RED-STRIPED-COTTON-TSHIRT.jpg'),
('HM548', 'BALLERNIAS PRINTED JERSEY DRESS', 'Kids', 'H&M', 4, 1750, 30, 'peekaboo.jpg'),
('NI271', 'Dri-FIT Challenger Knit Running Pants', 'Men Pants', 'Nike', 4, 7500, 16, 'c5954bbc-0dcb-422d-87a3-ca14b88f3a3e.jpg'),
('NI749', 'Phenom Elite Knit Running Pants', 'Men Pants', 'Nike', 3, 9500, 8, 'cu5504-010__1.jpg'),
('ZA231', 'ICE CREAM DRESS', 'Kids', 'Zara', 3, 2000, 7, '3905552645_6_1_1.jpg'),
('ZA537', 'LONG POINTELLE KNIT DRESS', 'Women Dresses', 'Zara', 3, 6000, 5, '3920007621_6_20_1.jpg'),
('ZA567', 'High Waist Trousers', 'Men Pants', 'Zara', 5, 2000, 9, '1608991800_6_1_1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `role` varchar(5) NOT NULL,
  `password` varchar(50) NOT NULL,
  `photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`first_name`, `last_name`, `email`, `user_name`, `role`, `password`, `photo`) VALUES
('Aayush', 'Tuladhar', 'aayush.tuladhar@gmail.com', 'AayushM_Tuladhar', 'user', '3á\n²ïGð³tõz6â', 'aayush.jpg'),
('Krish', 'Serchan', 'krish.serchan@gmail.com', 'Krish_Serchan003', 'user', 'innB	Ï¤¶Ñ Qÿ', 'krish.jpg'),
('Kritika', 'Baidawar', 'kritika.baidawar@gmail.com', 'Kritika_Baidawar', 'admin', 'ôKÛ1£g:\nGÌ', 'kritika.jpg'),
('Nayan', 'Pandey', 'nayan.pandey@gmail.com', 'Nayan_Pandey2002', 'user', 'ÎPÐácC¤BÁFè[Rã', 'nayan.jpg'),
('Rahul', 'Balami', 'rahul.balami@gmail.com', 'Rahul_Balami2004', 'user', '¢pÓlDç>ÐþCíù', 'rahul.jpg'),
('Ureeka', 'Serchan', 'ureeka.serchan@gmail.com', 'Ureeka_Serchan03', 'user', '¨Mù·Féj$', 'ureeka.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`user_name`,`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
