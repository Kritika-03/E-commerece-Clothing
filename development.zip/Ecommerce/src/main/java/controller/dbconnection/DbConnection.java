package controller.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.CartModel;
import model.Encryption;
import model.ProductModel;
import model.UserModel;
import resources.Constants;



public class DbConnection {
	public Connection getConnection(){
		try {
			Class.forName(Constants.DRIVER_NAME);
			Connection connection = DriverManager.getConnection(
					Constants.DB_URL,
					Constants.DB_USER,
					Constants.DB_PASS);
			System.out.println("Printing connection object "+connection);
			return connection;
		}catch(SQLException | ClassNotFoundException ex) {
			System.out.println("Database no");
			ex.printStackTrace();
			return null;
		}
	}
	
	public Boolean isRegistered(String username) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(Constants.CHECK_LOGIN_INFO);
				statement.setString(1, username);
				ResultSet result = statement.executeQuery();
				if(result.next()) {
					return true;		
				}else return false;
			} catch (SQLException e) { return null; }
		}else { return null; }
	}
	
	public Boolean canLogIn(String query, String username, String password) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, username);
				System.out.println(statement);
				ResultSet result = statement.executeQuery();
				if(result.next()) {
					String userDb = result.getString("user_name");
					System.out.println(userDb);
					String passwordDb  = result.getString("password");
					System.out.println(passwordDb);
					String encryptedPwd = Encryption.encrypt(password, username);
					System.out.println(encryptedPwd);
					if(encryptedPwd!=null && userDb.equals(username) && encryptedPwd.equals(passwordDb))return true;
					else {
						System.out.println("decrption no");
						return false;
					}
					
				}else {
					System.out.println("mo result");
					return false;
				}
			} catch (Exception e) { return null; }
		}else { return null; }
	}
	
	public int registerUser(String query, UserModel userModel) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				if(isRegistered(userModel.getUserName())) return -1;
				
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, userModel.getFirstName());
				statement.setString(2, userModel.getLastName());
				statement.setString(3, userModel.getEmail());
				statement.setString(4, userModel.getUserName());
				statement.setString(5, userModel.getRole());
				statement.setString(6, Encryption.encrypt(
						userModel.getPassword(),userModel.getUserName()));
				statement.setString(7, userModel.getImageUrlPart());

				int result = statement.executeUpdate();
				if(result>=0) {
					System.out.print("Yes");
					return 1;}
				else {
					System.out.print("No");
					return 0;}
			} catch (Exception e) { return -2; }
		}else { return -3; }
	}
	
	public boolean isAdmin(String username) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(Constants.USER_ROLE);
				statement.setString(1, username);
				ResultSet result = statement.executeQuery();
				if(result.next()) {
					String role = result.getString("role");
					System.out.println(role);
					if(role.equals("admin")) {return true;}
					else {return false;}
				}
				else {return false;}
			} catch (SQLException e) { return false; }
		}else { return false; }
	}
	
	public Boolean isAdded(String product_id) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(Constants.CHECK_PRODUCT_INFO);
				statement.setString(1, product_id);
				ResultSet result = statement.executeQuery();
				if(result.next()) {
					return true;		
				}else return false;
			} catch (SQLException e) { return null; }
		}else { return null; }
	}
	
	public int addProduct(String query, ProductModel productModel) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				if(isAdded(productModel.getProductId())) return -1;
				
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, productModel.getProductId());
				statement.setString(2, productModel.getProductName());
				statement.setString(3, productModel.getCategory());
				statement.setString(4, productModel.getBrand());
				statement.setInt(5, productModel.getRating());
				statement.setInt(6, productModel.getUnitPrice());
				statement.setInt(7, productModel.getStock());
				statement.setString(8, productModel.getImageUrlPart());

				int result = statement.executeUpdate();
				if(result>=0) {
					System.out.print("Yes");
					return 1;}
				else {
					System.out.print("No");
					return 0;}
			} catch (Exception e) { return -2; }
		}else { return -3; }
	}
	
	public Boolean deleteProduct(String query, String product_id) {
		Connection dbConnection = getConnection();
		System.out.println(product_id);
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, product_id);
				System.out.println(statement);
				int result = statement.executeUpdate();
				if(result>=0)return true;
				else return false;
			} catch (SQLException e) { return null; }
		}else { return null; }
	}
	
	public int editProduct(String query, ProductModel productModel) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				if(isAdded(productModel.getProductId())) {
				
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, productModel.getProductName());
				statement.setString(2, productModel.getCategory());
				statement.setString(3, productModel.getBrand());
				statement.setInt(4, productModel.getRating());
				statement.setInt(5, productModel.getUnitPrice());
				statement.setInt(6, productModel.getStock());
				statement.setString(7, productModel.getImageUrlPart());
				statement.setString(8, productModel.getProductId());

				int result = statement.executeUpdate();
				if(result>=0) {
					System.out.print("Yes");
					return 1;}
				else {
					System.out.print("No");
					return 0;}}
				else {return 0;}
			} catch (Exception e) { return -2; }
		}else { return -3; }
	}
	public Boolean deleteUser(String query, String user_name) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, user_name);
				int result = statement.executeUpdate();
				if(result>=0)return true;
				else return false;
			} catch (SQLException e) { return null; }
		}else { return null; }
	}
	public int editUser(String query, String first_name, String last_name, String photo, String user_name) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, first_name);
				statement.setString(2, last_name);
				statement.setString(3, photo);
				statement.setString(4, user_name);

				int result = statement.executeUpdate();
				if(result>=0) {
					System.out.print("Yes");
					return 1;}
				else {
					System.out.print("No");
					return 0;}
			} catch (Exception e) { return -2; }
		}else { return -3; }
	}
	public int changePass(String query, String new_pass, String user_name) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, Encryption.encrypt(new_pass,user_name));
				statement.setString(2, user_name);

				int result = statement.executeUpdate();
				if(result>=0) {
					System.out.print("Yes");
					return 1;}
				else {
					System.out.print("No");
					return 0;}
			} catch (Exception e) { return -2; }
		}else { return -3; }
	}
	public int addToCart(String query, CartModel cartModel) {
		Connection dbConnection = getConnection();
		if(dbConnection != null) {
			try {
				
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, cartModel.getUserName());
				statement.setString(2, cartModel.getProductId());
				statement.setInt(3, cartModel.getQuantity());
				PreparedStatement statement2 = dbConnection.prepareStatement("UPDATE products SET stock=stock-? WHERE product_id LIKE ?;");
				statement2.setInt(1, cartModel.getQuantity());
				statement2.setString(2, cartModel.getProductId());
				
				int result = statement.executeUpdate();
				int result2= statement2.executeUpdate();
				if(result>=0 && result2>=0) {
					System.out.print("Yes");
					return 1;}
				else {
					System.out.print("No");
					return 0;}
			} catch (Exception e) { return -2; }
		}else { return -3; }
	}
	
}
