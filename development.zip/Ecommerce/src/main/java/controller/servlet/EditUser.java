package controller.servlet;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import controller.dbconnection.DbConnection;
import resources.Constants;

/**
 * Servlet implementation class EditUser
 */
@WebServlet("/EditUser")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 10, // 10MB
maxRequestSize = 1024 * 1024 * 50)
public class EditUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String first_name = request.getParameter("e_fname");
		String last_name = request.getParameter("e_lname");
		Part imageUrlPart = request.getPart("e_photo");
		
		HttpSession session = request.getSession();
		String user_name=(String) session.getAttribute("user");
		
		String imageUrlPart_ = null;
		String savePath = Constants.IMAGE_DIR_SAVE_PATH;
		File saveDir = new File(savePath);
		if (!saveDir.exists()) {
			saveDir.mkdir();
		}
		String contentDisp = imageUrlPart.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				imageUrlPart_ = s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		if(imageUrlPart_ == null || imageUrlPart_.isEmpty()) {
			imageUrlPart_= "download.png";
		}
	    if(!imageUrlPart_.isEmpty() && imageUrlPart_ != null) {
	    	imageUrlPart.write(savePath +File.separator+imageUrlPart_);
	    }
	    
	    
	    DbConnection con = new DbConnection();
		int result = con.editUser(Constants.EDIT_USER, first_name, last_name, imageUrlPart_, user_name);
		if(result == 1) {
			request.setAttribute("updatedMessage", "Successfully Updated");
			request.getRequestDispatcher("/pages/profile.jsp").forward(request, response);
		}else if(result == -1) {
			request.setAttribute("updateMessage", "User Does not Exists");
			request.getRequestDispatcher("/pages/editProfile.jsp").forward(request, response);
		}else {
			System.out.println("No");
			request.getRequestDispatcher("/pages/editProfile.jsp").forward(request, response);
		}
	}
}

