package controller.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import controller.dbconnection.DbConnection;
import model.CartModel;
import resources.Constants;

/**
 * Servlet implementation class AddtoCart
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/AddtoCart" })
public class AddtoCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String product_id = request.getParameter("product_id");
		String quantity = request.getParameter("quantity");
		HttpSession session = request.getSession();
		String user=(String) session.getAttribute("user");
		
		int i_quantity=Integer.parseInt(quantity); 
		if(user!=null) {
		CartModel cartModel = new CartModel(user,product_id,i_quantity);
		
		
		
		DbConnection con = new DbConnection();
		int result = con.addToCart(Constants.ADD_CART, cartModel);
		if(result == 1) {
			request.setAttribute("addMessage", "Successfully Added");
			request.getRequestDispatcher("/pages/cart.jsp").forward(request, response);
		}else if(result == -1) {
			request.setAttribute("addMessage", "Cart Already Exists");
			request.getRequestDispatcher("/pages/search.jsp").forward(request, response);
		}else {
			System.out.println("NoNo");
			request.getRequestDispatcher("/pages/search.jsp").forward(request, response);
		}}
		else {
			request.getRequestDispatcher("/pages/login.jsp").forward(request, response);
		}
		
	}
}

