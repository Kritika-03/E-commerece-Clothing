package controller.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import controller.dbconnection.DbConnection;
import model.ProductModel;
import resources.Constants;


@WebServlet("/EditProductServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 10, // 10MB
maxRequestSize = 1024 * 1024 * 50)

public class EditProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String product_id = request.getParameter("e_p_id");
			String product_name = request.getParameter("e_p_name");
			String  category = request.getParameter("e_category");
			String  brand = request.getParameter("e_brand");
			String  rating = request.getParameter("e_rating");
			String  unit_price = request.getParameter("e_unit_price");
			String  stock = request.getParameter("e_stock");
			Part imageUrlPart = request.getPart("e_photo");	
			
			int i_rating=Integer.parseInt(rating); 
			int i_unit_price=Integer.parseInt(unit_price); 
			int i_stock=Integer.parseInt(stock); 
			
			ProductModel productModel = new ProductModel(product_id, product_name, category, brand, i_rating, i_unit_price, i_stock , imageUrlPart);
			
		    String savePath = Constants.IMAGE_DIR_SAVE_PATH;
		    String fileName = productModel.getImageUrlPart();
		    if(!fileName.isEmpty() && fileName != null)
	    		imageUrlPart.write(savePath + fileName);
			
			DbConnection con = new DbConnection();
			int result = con.editProduct(Constants.EDIT_PRODUCT, productModel);
			if(result == 1) {
				request.setAttribute("addMessage", "Successfully Updated");
				request.getRequestDispatcher("/pages/viewProduct.jsp").forward(request, response);
			}else if(result == -1) {
				request.setAttribute("addMessage", "Product Does not Exists");
				request.getRequestDispatcher("/pages/admin.jsp").forward(request, response);
			}else {
				System.out.println("No");
				request.getRequestDispatcher("/pages/admin.jsp").forward(request, response);
		}
	}

}
