package controller.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.dbconnection.DbConnection;
import resources.Constants;

/**
 * Servlet implementation class DeleteUser
 */
@WebServlet("/DeleteUser")
public class DeleteUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String user_name=(String) session.getAttribute("user");
		
		DbConnection con = new DbConnection();
		Boolean result = con.deleteUser(Constants.DELETE_USER, user_name);
		
		Cookie[] cookies = request.getCookies();
    	if(cookies != null){
	    	for(Cookie cookie : cookies){
	    		cookie.setMaxAge(0);
	    		response.addCookie(cookie);
	    	}
    	}
        // Clear session
    	session = request.getSession(false);
    	if(session != null){
    		session.invalidate();
    	}
    	
		if(result) {
			request.setAttribute("deleteMessage", "Successfully Deleted");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}else if(!result) {
			request.setAttribute("deleteMessage", "User Does not Exists");
			request.getRequestDispatcher("/pages/profile.jsp").forward(request, response);
		}else {
			System.out.println("No");
			request.getRequestDispatcher("/pages/profile.jsp").forward(request, response);
		}
		
	}

}
