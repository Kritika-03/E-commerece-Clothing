package controller.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import controller.dbconnection.DbConnection;
import resources.Constants;

/**
 * Servlet implementation class DeleteProductServlet
 */
@WebServlet("/DeleteProductServlet")
public class DeleteProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String product_id = request.getParameter("d_pid");
		System.out.println(product_id);
		DbConnection con = new DbConnection();
		Boolean result = con.deleteProduct(Constants.DELETE_PRODUCT, product_id);
		if(result) {
			request.setAttribute("deleteMessage", "Successfully Deleted");
			request.getRequestDispatcher("/pages/viewProduct.jsp").forward(request, response);
		}else if(!result) {
			request.setAttribute("deleteMessage", "Product Does not Exists");
			request.getRequestDispatcher("/pages/admin.jsp").forward(request, response);
		}else {
			System.out.println("No");
			request.getRequestDispatcher("/pages/admin.jsp").forward(request, response);
		}
		
	}
}
