package controller.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.dbconnection.DbConnection;
import resources.Constants;


@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String user_name=(String) session.getAttribute("user");
		String old_pass = request.getParameter("old_pass");
		String new_pass = request.getParameter("new_pass");
		
		DbConnection connection = new DbConnection();
		Boolean canLogIn = connection.canLogIn(Constants.CHECK_LOGIN_INFO, user_name, old_pass);
		if(canLogIn != null && canLogIn){
			int result = connection.changePass(Constants.NEW_PASS, new_pass, user_name);
			if(result == 1) {
				request.setAttribute("updatedMessage", "Successfully Updated");
				RequestDispatcher reqd = request.getRequestDispatcher("LogoutServlet");
				reqd.forward(request, response);
			}else if(result == -1) {
				request.setAttribute("updateMessage", "User Does not Exists");
				request.getRequestDispatcher("/pages/editProfile.jsp").forward(request, response);
			}else {
				System.out.println("No");
				request.getRequestDispatcher("/pages/editProfile.jsp").forward(request, response);
			}
		}
	}

}
