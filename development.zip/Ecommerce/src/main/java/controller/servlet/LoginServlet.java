package controller.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.dbconnection.DbConnection;
import resources.Constants;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String user_name = request.getParameter("user_name");
		String password = request.getParameter("password");
		
		DbConnection connection = new DbConnection();
		
		Boolean isAdmin = connection.isAdmin(user_name);
		System.out.println(isAdmin);
		Boolean canLogIn = connection.canLogIn(Constants.CHECK_LOGIN_INFO, user_name, password);
		
		if(canLogIn != null && canLogIn){
			HttpSession session = request.getSession();
			session.setAttribute("user", user_name);
			//setting session to expiry in 30 mins
			session.setMaxInactiveInterval(30*60);

			Cookie userName = new Cookie("user", user_name);
			userName.setMaxAge(30*60);
			response.addCookie(userName);
			if(isAdmin != null && isAdmin) {
				response.sendRedirect(request.getContextPath()+"/pages/admin.jsp");
			}
			else {response.sendRedirect(request.getContextPath()+"/index.jsp");}
		}else{
			// set error message
			System.out.println("Invalid");
		    request.setAttribute("errorMessage", "Invalid username or password");
		    // forward request to login page
		    request.getRequestDispatcher("/pages/login.jsp").include(request, response);
		}
	}

}
