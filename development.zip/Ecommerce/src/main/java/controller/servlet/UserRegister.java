package controller.servlet;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import controller.dbconnection.DbConnection;
import model.UserModel;
import resources.Constants;


@WebServlet(asyncSupported = true, urlPatterns = { "/UserRegister" })
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 10, // 10MB
maxRequestSize = 1024 * 1024 * 50)

public class UserRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String first_name = request.getParameter("first_name");
		String last_name = request.getParameter("last_name");
		String  email = request.getParameter("email");
		String  user_name = request.getParameter("user_name");
		String  password = request.getParameter("password");
		String  role = request.getParameter("role");
		Part imageUrlPart = request.getPart("photo");	
		
		UserModel userModel = new UserModel(first_name, last_name, email, user_name, password, role, imageUrlPart);
		
	    String savePath = Constants.IMAGE_DIR_SAVE_PATH;
	    String fileName = userModel.getImageUrlPart();
	    if(!fileName.isEmpty() && fileName != null) {
	    	imageUrlPart.write(savePath +File.separator+fileName);
	    }
    		
		
		DbConnection con = new DbConnection();
		int result = con.registerUser(Constants.USER_REGISTER, userModel);
		if(result == 1) {
			request.setAttribute("registerMessage", "Successfully Registered");
			request.getRequestDispatcher("/pages/login.jsp").forward(request, response);
		}else if(result == -1) {
			request.setAttribute("registerMessage", "User Already Exists");
			request.getRequestDispatcher("/pages/register.jsp").forward(request, response);
		}else {
			System.out.println("No");
			request.getRequestDispatcher("/pages/register.jsp").forward(request, response);
		}
		
	}

}
