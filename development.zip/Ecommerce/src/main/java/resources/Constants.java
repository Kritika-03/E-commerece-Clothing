package resources;

import java.io.File;

public class Constants {
	public static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/ecommerce_app";
	public static final String DB_USER = "root";
	public static final String DB_PASS = "";
	
	
	public static final String IMAGE_DIR = "xampp\\htdocs\\images\\";
	public static final String IMAGE_DIR_SAVE_PATH = "C:" + File.separator + IMAGE_DIR;
//	public static final String IMAGE_DIR_SAVE_PATH = "/images";
	
	public static final String CHECK_LOGIN_INFO = "SELECT user_name, password FROM users WHERE user_name LIKE ?";
	public static final String CHECK_PRODUCT_INFO = "SELECT product_id, product_name FROM products WHERE product_id LIKE ?";
	
	public static final String USER_ROLE = "SELECT role FROM users WHERE user_name LIKE ?";
	
	public static final String GET_USER = "SELECT * FROM users WHERE user_name LIKE ?";
	public static final String USER_REGISTER = "INSERT INTO users"
			+ "(first_name, last_name, email, user_name, role, password, photo)"
			+ " VALUES(?,?,?,?,?,?,?)";
	public static final String DELETE_USER = "DELETE FROM users WHERE user_name LIKE ?";
	
	public static final String EDIT_USER = "UPDATE users SET first_name=?, "
			+ "last_name=?, photo=? WHERE user_name=?";
	public static final String 	ADD_PRODUCT = "INSERT INTO products"
			+ "(product_id, product_name, category, brand, rating, unit_price, stock, photo)"
			+ " VALUES(?,?,?,?,?,?,?,?)";
	public static final String DELETE_PRODUCT = "DELETE FROM products WHERE product_id LIKE ?";
	public static final String EDIT_PRODUCT = "UPDATE products SET product_name=?, "
			+ "category=?, brand=?, rating=?, unit_price=?, stock=?, photo=? WHERE product_id=?";
	public static final String NEW_PASS = "UPDATE users SET password=? WHERE user_name LIKE ?";
	
	public static final String ADD_CART = "INSERT INTO carts"
			+ "(user_name, product_id, quantity)"
			+ " VALUES(?,?,?)";
	
	public static final String ALL_PRODUCTS = "SELECT * FROM products";
}

