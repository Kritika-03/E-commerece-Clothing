package model;

import java.io.File;

import javax.servlet.http.Part;

import resources.Constants;

public class ProductModel {
	private String product_id, product_name,category, brand, imageUrlPart;
	private int rating, unit_price, stock;
	
	public ProductModel() {}
	
	public ProductModel(String product_id, String product_name, String category, String brand, int rating, int unit_price,int stock , Part part){
		this.product_id = product_id;
		this.product_name = product_name;
		this.category = category;
		this.brand = brand;
		this.rating = rating;
		this.unit_price = unit_price;
		this.stock = stock;		
		this.imageUrlPart = getImageUrl(part);
	}
	
	public String getImageUrlPart() {
		return imageUrlPart;
	}
	
	public void setImageUrlPart(Part part) {
		this.imageUrlPart = getImageUrl(part);
	}
	
	public String getProductId() {
		return product_id;
	}
	public void setProductId(String product_id) {
		this.product_id = product_id;
	}
	public String getProductName() {
		return product_name;
	}
	public void setProductName(String product_name) {
		this.product_name = product_name;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getCategory() {
		return category;
	}
	public String getBrand() {
		return brand	;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public int getUnitPrice() {
		return unit_price;
	}
	public void setUnitPrice(int unit_price) {
		this.unit_price = unit_price;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	
	private String getImageUrl(Part part) {
		String savePath = Constants.IMAGE_DIR_SAVE_PATH;
		File saveDir = new File(savePath);
		String imageUrlPart = null;
		if (!saveDir.exists()) {
			saveDir.mkdir();
		}
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				imageUrlPart = s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		if(imageUrlPart == null || imageUrlPart.isEmpty()) {
			imageUrlPart= "download.png";
		}
		return imageUrlPart;
	}
}
