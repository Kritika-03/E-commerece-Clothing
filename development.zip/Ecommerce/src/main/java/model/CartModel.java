package model;

public class CartModel {
	private String user_name, product_id;
	private int quantity;
	public CartModel() {}
	public CartModel(String user_name, String product_id, int quantity) {
		this.user_name = user_name;
		this.product_id = product_id;
		this.quantity= quantity;
	}
	public void setUserName(String user_name) {
		this.user_name = user_name;
	}
	public String getUserName() {
		return user_name;
	}
	public void setProductId(String product_id) {
		this.product_id = product_id;
	}
	public String getProductId() {
		return product_id;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getQuantity() {
		return quantity;
	}
}
