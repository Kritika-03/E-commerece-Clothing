package model;

import java.io.File;

import javax.servlet.http.Part;

import resources.Constants;

public class UserModel {
	private String first_name, last_name, email,user_name, password, role, imageUrlPart;

	public UserModel() {}
	
	public UserModel(String first_name, String last_name, String email, String user_name, 
			String password, String role, Part part){
		this.first_name = first_name;
		this.last_name = last_name;
		this.user_name = user_name;
		this.email = email;
		this.password = password;
		this.role = role;
		this.imageUrlPart = getImageUrl(part);
	}
	
	public String getImageUrlPart() {
		return imageUrlPart;
	}
	
	public void setImageUrlPart(Part part) {
		this.imageUrlPart = getImageUrl(part);
	}
	
	public String getFirstName() {
		return first_name;
	}
	public void setFirstName(String first_name) {
		this.first_name = first_name;
	}
	public String getLastName() {
		return last_name;
	}
	public void setLastName(String last_name) {
		this.last_name = last_name;
	}
	public void setUserName(String user_name) {
		this.user_name = user_name;
	}
	public String getUserName() {
		return user_name;
	}
	public String getEmail() {
		return email	;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	private String getImageUrl(Part part) {
		String savePath = Constants.IMAGE_DIR_SAVE_PATH;
		File saveDir = new File(savePath);
		String imageUrlPart = null;
		if (!saveDir.exists()) {
			saveDir.mkdir();
		}
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				imageUrlPart = s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		if(imageUrlPart == null || imageUrlPart.isEmpty()) {
			imageUrlPart= "download.png";
		}
		
		return imageUrlPart;
	}
}
